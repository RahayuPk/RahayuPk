{
  "Arabica": [
    {
      "nama": "Kopi Arabika Sidikalang",
      "size": "1.000 Gram",
      "harga": "148.000",
      "foto": "https://rikikurnia.com/prakerja/api/img/1.jpg",
      "link": "https://www.tokopedia.com/sopic-store/kopi-arabika-sidikalang-1000-gr-biji"
    },
    {
      "nama": "Kopi Arabica Aceh Gayo Super",
      "size": "500 Gram",
      "harga": "58.000",
      "foto": "https://rikikurnia.com/prakerja/api/img/2.jpg",
      "link": "https://www.tokopedia.com/sopic-store/kopi-arabica-aceh-gayo-super-500-gr-bubuk-kasar"
    },
    {
      "nama": "Kopi Arabica Gayo Honey Process",
      "size": "1.000 Gram",
      "harga": "200.000",
      "foto": "https://rikikurnia.com/prakerja/api/img/3.jpg",
      "link": "https://www.tokopedia.com/sopic-store/kopi-arabica-gayo-honey-process-1-kg-bubuk-halus"
    },
    {
      "nama": "Kopi Arabica Gayo Premium Specialty",
      "size": "200 Gram",
      "harga": "49.000",
      "foto": "https://rikikurnia.com/prakerja/api/img/4.jpg",
      "link": "https://www.tokopedia.com/sopic-store/kopi-arabica-gayo-premium-specialty-200-gr-bubuk-biji-grosir-biji"
    },
    {
      "nama": "Kopi Luwak Liar Arabica Gayo",
      "size": "1.000 Gram",
      "harga": "280.000",
      "foto": "https://rikikurnia.com/prakerja/api/img/5.jpg",
      "link": "https://www.tokopedia.com/sopic-store/kopi-luwak-liar-arabica-gayo-1kg-biji-bubuk-bubuk-halus"
    },
    {
      "nama": "Kopi Arabica Gayo Peaberry",
      "size": "500 Gram",
      "harga": "105.000",
      "foto": "https://rikikurnia.com/prakerja/api/img/6.jpg",
      "link": "https://www.tokopedia.com/sopic-store/kopi-arabica-gayo-peaberry-jantan-500-gr-bubuk-biji-biji"
    },
    {
      "nama": "Kopi Arabica Gayo Wine",
      "size": "500 Gram",
      "harga": "118.000",
      "foto": "https://rikikurnia.com/prakerja/api/img/7.jpg",
      "link": "https://www.tokopedia.com/sopic-store/kopi-arabika-gayo-wine-500-gr-biji-bubuk-grosir-reseller-dropshiper-bubuk-halus"
    }
  ],
  "Robusta": [
    {
      "nama": "Kopi Aceh Robusta Gayo Natural Premium",
      "size": "250 Gram",
      "harga": "25.000",
      "foto": "https://rikikurnia.com/prakerja/api/img/8.jpg",
      "link": "https://www.tokopedia.com/sopic-store/kopi-aceh-robusta-gayo-natural-premium-250-gr-bubuk-kasar"
    },
    {
      "nama": "Kopi Robusta Natural Sidikalang Premium",
      "size": "500 Gram",
      "harga": "40.000",
      "foto": "https://rikikurnia.com/prakerja/api/img/9.jpg",
      "link": "https://www.tokopedia.com/sopic-store/kopi-robusta-natural-sidikalang-premium-500-gr-biji"
    }
  ],
  "Non Kopi": [
    {
      "nama": "Es Krim Mangkok",
      "size": "250 Gram",
      "harga": "25.000",
      "foto": "https://p0.pxfuel.com/preview/861/839/598/ice-ice-cream-ice-cream-sundae-sweet.jpg",
      "link": "https://www.tokopedia.com/jakartagrosirjaya/aice-vanilla-chocolate-sundae-ice-cream-eskrim-800-ml"
    }
  ],
  "null": [
    {
      "nama": "Nama produk",
      "size": "100ml",
      "harga": "10.000",
      "link": "#",
      "foto": "images/produk/product_kopi_susu.jpg"
    }
  ]
}